# Quote of the Day application
  This chart installs ```Quote of the Day``` application as per placement policy
## Install the chart
  ```helm install --name myqodapp qodapp-<version>.tgz```
