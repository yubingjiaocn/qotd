# Quote of the Day Database

This is a MariaDB database of quotes from famous people.  It is used in the
Quote of the Day (qod) sample app, used to demonstrate Multicloud Manager application functionality.  It is part of a three tired web application; qod-web, qod-api, and qod-db, that dishes up a different quote each day 
(from a total of over 70k of them).

